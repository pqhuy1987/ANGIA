<div class="jeg_sidebar <?php echo esc_attr( $sidebar['position-sidebar'] . ' ' . $sidebar['sticky-sidebar'] ); ?> col-sm-<?php echo esc_attr($sidebar['width-sidebar']); ?>">
    <?php jnews_widget_area( $sidebar['content-sidebar'] ); ?>
</div>
