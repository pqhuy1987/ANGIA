
            </div>
        </div>
    </div>
    <?php do_action('jnews_after_main'); ?>
</div>

<?php
get_template_part('footer');
?>


