Change Log :

== 5.2.1 ==
- fix ajax loaded split post contain related post

== 5.2.0 ==
- fix issue with shortcode

== 5.0.2 ==
- [IMPROVEMENT] Use .on()

== 5.0.1 ==
- [BUG] Fix split post heading issue

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.3 ==
- [BUG] Fix split post 19 issue
- [BUG] Fix ads issue on split post content
- [BUG] Disable mouse drag event

== 3.0.2 ==
- [BUG] Fix split post content issue with jQuery

== 3.0.1 ==
- [BUG] Fix issue with OwlCarousel

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.1.0 ==
- [IMPROVEMENT] Make jnews split compatible with php 7.1

== 1.0.2 ==
- [IMPROVEMENT] Prevent plugin conflict by changing ajax_url variable name

== 1.0.1 ==
- [BUG] Fix issue when JNews - Autoload used along with JNews - Split
- [IMPROVEMENT] Split post to scroll into split post content when next page clicked on normal mode
