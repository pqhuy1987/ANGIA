=== 1.2.1 ==
- fix refresh issue on customizer previewer

=== 1.2.0 ==
- Minor css fix for wrong loader position
- Add Redirect Tag functionality

=== 1.1.0 ==
- [NEW FEATURE] New ajax control
- [IMPROVEMENT] Include style generator for get option
- [BUG] Fix bug some CSS not rendered correctly on Customizer
- [BUG] Fix cannot redeclare certain function issue
- [BUG] Fix can't edit widgets cause by parsing error

=== 1.0.0 ===
- This customizer plugin is fork of Kirki (https://github.com/aristath/kirki) to extend its ability :
- Better handling for active callback (active callback not depend on page refresh)
- Style Generator for Customizer Control
- Redirect page when control changed

