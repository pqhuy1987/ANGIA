Change Log :

== 5.0.1 ==
- [IMPROVEMENT] Use hooks to override page template

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.2 ==
- [BUG] Fix wp media issue

== 4.0.1 ==
- [BUG] Fix metabox issue with WooCommerce

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.3 ==
- [IMPROVEMENT] Improve customizer speed performance

== 2.0.2 ==
- [BUG] Fix undefined label index issue on account page

== 2.0.1 ==
- [IMPROVEMENT] Use modified date instead creation date on post meta date

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.0 ==
- First Release
