(function($){
    'use strict';

    // New Select Mechanism
    var ajaxCall = function (query, callback) {
        var field = this;
        if (!query.length || query.length < 3) return callback();

        var request = wp.ajax.send(field.ajax, {
            data: {
                query: query,
                nonce: field.nonce
            }
        });

        request.done(function (response) {
            callback(response);
        });
    };

    $('.vc-select-wrapper').each(function () {
        var ajax = $(this).data('ajax'),
            multiple = $(this).data('multiple'),
            nonce = $(this).data('nonce'),
            input, setting;

        if (multiple > 1) {
            var optionText = $(this).find(".data-option").text();
            var options = JSON.parse(optionText);
            input = $(this).find('input');

            setting = {
                plugins: ['drag_drop', 'remove_button'],
                multiple: multiple,
                hideSelected: true,
                persist: true,
                options: options,
                render: {
                    option: function (item) {
                        return '<div><span>' + item.text + '</span></div>';
                    }
                }
            };
        } else {
            input = $(this).find('select');
            setting = {
                allowEmptyOption: true
            };
        }

        if (ajax !== '') {
            setting.load = ajaxCall.bind({
                ajax: ajax,
                nonce: nonce
            });
            setting.create = true;
        }

        $(input).selectize(setting);
    });
})(window.jQuery);
